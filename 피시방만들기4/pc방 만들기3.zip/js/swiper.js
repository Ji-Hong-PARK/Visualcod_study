new Swiper('nav>.leftmenu>.swiper',{
  direction:'vertical',
  autoplay:true, //3000m/s 기본
  lopp:true
})